package fj.swsk.cn.eqapp.map.search;

/**
 * Created by xul on 2016/6/22.
 */
public class Poi {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    String name;

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    double x;

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }

    double y;

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    String address;
}
