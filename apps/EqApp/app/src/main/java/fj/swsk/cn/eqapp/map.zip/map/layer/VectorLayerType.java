package fj.swsk.cn.eqapp.map.layer;

/**
 * Created by xul on 2016/6/28.
 */

public enum VectorLayerType{
        POINT,
        POLYLINE,
        POLYGON
}