package fj.swsk.cn.eqapp.map.adapter;

/**
 * Created by xul on 2016/7/30.
 */
public interface myViewHolder {
     void update();
}
