package fj.swsk.cn.eqapp.map;

import java.util.Map;

/**
 * Created by xul on 2016/6/28.
 */
public class DeathTheaticInfo {
    public Map<Integer,Object> map;
}

